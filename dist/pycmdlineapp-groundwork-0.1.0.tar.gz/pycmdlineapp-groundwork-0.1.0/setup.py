# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pycmdlineapp_groundwork',
 'pycmdlineapp_groundwork.commandline',
 'pycmdlineapp_groundwork.config',
 'pycmdlineapp_groundwork.factory',
 'pycmdlineapp_groundwork.logging',
 'pycmdlineapp_groundwork.utility']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2>=2.11.2,<3.0.0',
 'deepmerge>=0.1.1,<0.2.0',
 'pyaml>=20.4.0,<21.0.0',
 'pytest>=6.2.2,<7.0.0',
 'schema>=0.7.3,<0.8.0',
 'typer>=0.3.2,<0.4.0']

setup_kwargs = {
    'name': 'pycmdlineapp-groundwork',
    'version': '0.1.0',
    'description': 'Startingpoint for any python-based commandline app with configuration, argument-parsing, help and logging prepared.',
    'long_description': None,
    'author': 'bnaard',
    'author_email': 'bnaard@gmx.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
