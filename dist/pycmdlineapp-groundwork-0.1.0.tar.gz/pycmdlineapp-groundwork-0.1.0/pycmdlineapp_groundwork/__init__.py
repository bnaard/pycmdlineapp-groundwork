"""PyCmdLineApp-Groundwork, all the boilerplate for jump-starting a Python CLI app."""

__version__= "0.1.0"

